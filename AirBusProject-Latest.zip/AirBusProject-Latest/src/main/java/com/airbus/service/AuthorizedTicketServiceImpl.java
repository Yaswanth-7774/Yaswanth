package com.airbus.service;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.airbus.pojos.AuthorizedTicket;


@Repository
public class AuthorizedTicketServiceImpl implements AuthorizedTicketService {
	@PersistenceContext

	EntityManager entityManager;
	@Transactional
	public void addAuthorizedTicket(AuthorizedTicket aRef) {
		// TODO Auto-generated method stub
		entityManager.persist(aRef);
	}

	@Transactional
	public AuthorizedTicket findAuthorizedTicket(Integer id) {
		// TODO Auto-generated method stub
		return entityManager.find(AuthorizedTicket.class,id);
	}
@SuppressWarnings({ "unchecked", "rawtypes" })
	
	@Transactional
	public Set<AuthorizedTicket> findAuthorizedTickets() {
		Set<AuthorizedTicket> AuthTickSet;
		 Query query = entityManager.createQuery("from AuthorizedTicket");
			
			AuthTickSet = new HashSet(query.getResultList());
	         
		        
			    return AuthTickSet;
	}

	@Transactional
	public void modifyAuthorizedTicket(AuthorizedTicket aRef) {
		// TODO Auto-generated method stub
		entityManager.merge(aRef);
	}

	@Transactional
	public void removeAuthorizedTicket(Integer id) {
		// TODO Auto-generated method stub
		AuthorizedTicket aTemp = entityManager.find(AuthorizedTicket.class,id);
		entityManager.remove(aTemp);
	}



}