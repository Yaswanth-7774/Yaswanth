package com.airbus.service;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.airbus.pojos.BusRoute;
import com.airbus.repos.BusRouteRepository;
import com.airbus.service.exception.BusRouteAlreadyExistsException;
import com.airbus.service.exception.BusRouteNotFoundException;

@Service
public class BusRouteServiceImpl implements BusRouteService {
	@Autowired
	BusRouteRepository busRouRepo;
	@Override
	public String addBusRouteService(BusRoute busRou) throws BusRouteAlreadyExistsException {
		System.out.println("Bus Service....Some scope of business logic here....");
		try {
			busRouRepo.addBusRoute(busRou);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new BusRouteAlreadyExistsException("Bus Route Already Exists");			
		}
		return "Bus Route Added Successfully";
		
	}
	@Override
	public BusRoute findBusRouteService(Integer rno) throws BusRouteNotFoundException {
		
		return null;
	}
	@Override
	public Set<BusRoute> findBusRoutesService() {
		
		return null;
	}
	@Override
	public String modifyBusRouteService(BusRoute bRou) throws BusRouteNotFoundException {
		
		return null;
	}
	@Override
	public String removeBusRouteService(Integer rno) throws BusRouteNotFoundException {
		
		return null;
	}

	@Override
	public Set<BusRoute> busSearchService(String Source, String Destination)  throws BusRouteNotFoundException {

		System.out.println("Busroute service is called");
		Set<BusRoute> busRouteSet = null;
		
        try
        {
        	busRouteSet= new HashSet(busRouRepo.busSearch(Source, Destination));
        	boolean isEmpty = busRouteSet.isEmpty();
    		if(isEmpty==false)
    		{
    			System.out.println("The available buses from "+Source+" to "+Destination+" are");
    			for (BusRoute d: busRouteSet) {
    				System.out.println("RouteNumber : "+d.getRouteNumber()); System.out.println("BusNumber   : "+d.getBus().getBusNumber());
    				System.out.println("Facility    : "+d.getFacility());    System.out.println("StartTime   : "+d.getStartTime());
    				System.out.println("End Time    : "+d.getEndTime());     System.out.println("Fare        : "+d.getFare());
    				System.out.println("Distance    : "+d.getDistance());    System.out.println("-----------------");
    				}
    		}	
    		else throw new BusRouteNotFoundException("No buses running in this route");
		} 
        catch (Exception e)
        {	
			e.printStackTrace();
		}
        return busRouteSet;
	}
	

}
