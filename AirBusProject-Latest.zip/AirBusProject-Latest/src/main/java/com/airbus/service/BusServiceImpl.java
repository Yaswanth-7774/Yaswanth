package com.airbus.service;


import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.airbus.pojos.Bus;




@Repository
public class BusServiceImpl implements BusService {
	@PersistenceContext
	EntityManager entityManager;
	@Transactional
	public void addBus(Bus bus) {
		// TODO Auto-generated method stub
		entityManager.persist(bus);
	}

	@Transactional
	public Bus findBus(Integer bno) {
		// TODO Auto-generated method stub
		return entityManager.find(Bus.class,bno);
	}

	@Transactional
	public Set<Bus> findBuses() {
		Set<Bus> busSet;
        Query query = entityManager.createQuery("from Buses");
        
        busSet = new HashSet(query.getResultList());
   
    return busSet;
    }

	@Transactional
	public void modifyBus(Bus bus) {
		// TODO Auto-generated method stub
		entityManager.merge(bus);
	}

	@Transactional
	public void removeBus(Integer bno) {
		// TODO Auto-generated method stub
		Bus bTemp = entityManager.find(Bus.class,bno);
		entityManager.remove(bTemp);
	}

}
