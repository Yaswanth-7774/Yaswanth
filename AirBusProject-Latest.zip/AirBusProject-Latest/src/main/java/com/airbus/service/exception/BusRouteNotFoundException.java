package com.airbus.service.exception;

public class BusRouteNotFoundException extends Exception {

	public BusRouteNotFoundException(String message) {
		super(message);

	}

}
