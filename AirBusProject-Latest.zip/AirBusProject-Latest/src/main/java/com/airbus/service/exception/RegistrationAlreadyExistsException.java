package com.airbus.service.exception;

@SuppressWarnings("serial")
public class RegistrationAlreadyExistsException extends Throwable {

	public RegistrationAlreadyExistsException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}

}