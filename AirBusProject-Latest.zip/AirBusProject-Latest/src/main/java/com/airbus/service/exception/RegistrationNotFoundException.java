package com.airbus.service.exception;
@SuppressWarnings("serial")
public class RegistrationNotFoundException extends Throwable {

	public RegistrationNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
