package com.airbus.service;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airbus.pojos.Registration;
import com.airbus.repos.RegistrationRepository;
import com.airbus.service.exception.RegistrationAlreadyExistsException;
import com.airbus.service.exception.RegistrationNotFoundException;




@Service
public class RegistrationServiceImpl implements RegistrationService {
	@Autowired
	RegistrationRepository  regRepo;
	
	@Override
	public String addRegistrationService(Registration reg) throws RegistrationAlreadyExistsException {
		try {
			regRepo.addRegistration(reg);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new RegistrationAlreadyExistsException("Registration already exists");
			
		}
		return "Registration added successfully";
	}

	@Override
	public Registration findRegistrationService(String email) {
		// TODO Auto-generated method stub
		return regRepo.findRegistration(email);
	}

	@Override
	public Set<Registration> findRegistrationsService() {
		// TODO Auto-generated method stub
		return regRepo.findRegistrations();
	}

	@Override
	public String modifyRegistrationService(Registration reg) throws RegistrationNotFoundException {
		Registration reg1 =regRepo.findRegistration(reg.getEmail());
		if(reg1!=null)
		{regRepo.modifyRegistration(reg);}
		else {
			throw new RegistrationNotFoundException("Registration Not Found");
		}
	 
	return "Registration modified successfully";
		
	}

	@Override
	public String removeRegistrationService(String email) throws RegistrationNotFoundException {
		Registration reg1 =regRepo.findRegistration(email);
		if(reg1!=null)
		{regRepo.removeRegistration(reg1.getEmail());}
		else {
			throw new RegistrationNotFoundException("Registration Not Found");
		}
		return "Registration Deleted successfully";
	}

	@Override
	public Registration userAuthenticationService(String userEmail, String userPassword) throws RegistrationNotFoundException {
		// TODO Auto-generated method stub
		Registration user= regRepo.findRegistration(userEmail);
		System.out.println(userEmail);
		String dataBasePassword;
		if(user!=null)
		{
			dataBasePassword=user.getPassword();
			
		}
		else
			throw new RegistrationNotFoundException("User Not Found");
		if(!dataBasePassword.equalsIgnoreCase(userPassword))
		{
			throw new RegistrationNotFoundException("Invalid Credentials");
		}
		return user;
	}

}
