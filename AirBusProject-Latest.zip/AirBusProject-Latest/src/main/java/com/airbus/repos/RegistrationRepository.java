package com.airbus.repos;


import java.util.Set;

import org.springframework.stereotype.Repository;


import com.airbus.pojos.Registration;


@Repository
public interface RegistrationRepository {
	
	void addRegistration(Registration reg);
	Registration findRegistration(String email);
	Set<Registration> findRegistrations();
	void modifyRegistration(Registration reg);
	void removeRegistration(String email);
}
