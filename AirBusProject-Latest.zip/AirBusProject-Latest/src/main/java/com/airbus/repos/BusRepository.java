package com.airbus.repos;

import java.util.Set;

import org.springframework.stereotype.Repository;

import com.airbus.pojos.Bus;




@Repository
public interface BusRepository {
	
	void addBus(Bus bus);
	Bus findBus(Integer bno);
	Set<Bus> findBuses();
	void modifyBus(Bus bus);
	void removeBus(Integer bno);
}
