package com.airbus.pojos;

import java.sql.Date;
import java.util.Set;
import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="reservation")
public class Reservation {
	
	@Id
	@Column(name="TICKETNUMBER")
	private Integer ticketNumber;
	
	@Column(name="BOOKINGDATE", columnDefinition = "DATE")
	private LocalDate bookingDate=LocalDate.now();
	
	@Column(name="JOURNEYDATE", columnDefinition = "DATE")
	private LocalDate journeyDate=LocalDate.now();
	
	@Column(name="SEATNUMBER")
	private Integer seatNumber;
	
	@Column(name="TICKETSTATUS")
	private String ticketStatus;
	
	@Column(name="CANCELLATIONDATE", columnDefinition = "DATE")
	private LocalDate cancellationDate=LocalDate.now();
	
	@Column(name="RESCHEDULEDDATE", columnDefinition = "DATE")
	private LocalDate rescheduledDate =LocalDate.now();;
	
	@Column(name="REFUND")
	private Integer refund;
	
	@Column(name="TRANSACTIONID")
	private Integer transactionId;

	@ManyToOne
	@JoinColumn(name="ROUTENUMBER")
	private BusRoute route;
	
	@OneToOne(mappedBy="reservation")
	private AuthorizedTicket authTicket;
	
	@OneToOne(mappedBy="reservation", cascade=CascadeType.ALL)
	@PrimaryKeyJoinColumn
	private UnAuthorizedTicket unAuthTicket;
	
	public Reservation() {
		super();
		System.out.println("Reservation is called");
	}

	public Integer getTicketNumber() {
		return ticketNumber;
	}

	public void setTicketNumber(Integer ticketNumber) {
		this.ticketNumber = ticketNumber;
	}

	public LocalDate getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(LocalDate bookingDate) {
		this.bookingDate = bookingDate;
	}

	public LocalDate getJourneyDate() {
		return journeyDate;
	}

	public void setJourneyDate(LocalDate journeyDate) {
		this.journeyDate = journeyDate;
	}

	public Integer getSeatNumber() {
		return seatNumber;
	}

	public void setSeatNumber(Integer seatNumber) {
		this.seatNumber = seatNumber;
	}

	public String getTicketStatus() {
		return ticketStatus;
	}

	public void setTicketStatus(String ticketStatus) {
		this.ticketStatus = ticketStatus;
	}

	public LocalDate getCancellationDate() {
		return cancellationDate;
	}

	public void setCancellationDate(LocalDate cancellationDate) {
		this.cancellationDate = cancellationDate;
	}

	public LocalDate getRescheduledDate() {
		return rescheduledDate;
	}

	public void setRescheduledDate(LocalDate rescheduledDate) {
		this.rescheduledDate = rescheduledDate;
	}

	public Integer getRefund() {
		return refund;
	}

	public void setRefund(Integer refund) {
		this.refund = refund;
	}

	public Integer getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Integer transactionId) {
		this.transactionId = transactionId;
	}

	@JsonIgnore
	public BusRoute getRoute() {
		return route;
	}

	public void setRoute(BusRoute route) {
		this.route = route;
	}

	public AuthorizedTicket getAuthTicket() {
		return authTicket;
	}

	public void setAuthTicket(AuthorizedTicket authTicket) {
		this.authTicket = authTicket;
	}

	public UnAuthorizedTicket getUnAuthTicket() {
		return unAuthTicket;
	}

	public void setUnAuthTicket(UnAuthorizedTicket unAuthTicket) {
		this.unAuthTicket = unAuthTicket;
	}

	
}
