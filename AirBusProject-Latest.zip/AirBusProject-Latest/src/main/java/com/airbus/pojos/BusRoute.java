package com.airbus.pojos;


import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.HashSet;
import java.util.Set;


/**
 * The persistent class for the BUSROUTE database table.
 * 
 */
@Entity
@Table(name="busroute")
public class BusRoute  {

	@Id
	//@GeneratedValue
	@Column(name="ROUTENUMBER")
	private Integer routeNumber;
	
	@Column(name="SOURCE")
	private String source;
	
	@Column(name="DESTINATION")
	private String destination;

	@Column(name="DISTANCE")
	private Integer distance;
	
	@Column(name="STARTTIME")
	private String startTime;
	
	@Column(name="ENDTIME")
	private String endTime;

	@Column(name="FACILITY")
	private String facility;

	@Column(name="FARE")
	private Integer fare;

	//bi-directional many-to-one association to Buses
	@ManyToOne
	@JoinColumn(name="BUSNUMBER")
	private Bus bus;

	//bi-directional many-to-one association to Reservation
	@OneToMany(mappedBy="route", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	Set<Reservation> resvSet = new HashSet<Reservation>();

	public BusRoute() {
		System.out.println("BusRoute called");
	}

	public Integer getRouteNumber() {
		return routeNumber;
	}

	public void setRouteNumber(Integer routeNumber) {
		this.routeNumber = routeNumber;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public Integer getDistance() {
		return distance;
	}

	public void setDistance(Integer distance) {
		this.distance = distance;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getFacility() {
		return facility;
	}

	public void setFacility(String facility) {
		this.facility = facility;
	}

	public Integer getFare() {
		return fare;
	}

	public void setFare(Integer fare) {
		this.fare = fare;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	@JsonIgnore
	public Bus getBus() {
		return bus;
	}

	public void setBus(Bus bus) {
		this.bus = bus;
	}
	@JsonIgnore
	public Set<Reservation> getResvSet() {
		return resvSet;
	}

	public void setResvSet(Set<Reservation> resvSet) {
		this.resvSet = resvSet;
	}

}