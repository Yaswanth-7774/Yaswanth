package com.airbus.pojos;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="BUSES")
public class Bus {

	@Id
	//@GeneratedValue
	@Column(name="BUSNUMBER")
	private Integer busNumber;

	@Column(name="FACILITY")
	private String facility;

	@Column(name="STATUS")
	private String status;
	
	@OneToMany(mappedBy="bus", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	Set<BusRoute> routeSet = new HashSet<BusRoute>();
	
	public Bus() {
		super();
		System.out.println("Buses constructor()......");
	}

	public Integer getBusNumber() {
		return busNumber;
	}

	public void setBusNumber(Integer busNumber) {
		this.busNumber = busNumber;
	}

	public String getFacility() {
		return facility;
	}

	public void setFacility(String facility) {
		this.facility = facility;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Set<BusRoute> getRouteSet() {
		return routeSet;
	}

	public void setRouteSet(Set<BusRoute> routeSet) {
		this.routeSet = routeSet;
	}
	
}