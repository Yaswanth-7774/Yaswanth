package com.airbus.controller;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.airbus.pojos.BusRoute;
import com.airbus.service.BusRouteService;
import com.airbus.service.exception.BusRouteAlreadyExistsException;
import com.airbus.service.exception.BusRouteNotFoundException;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class BusRouteController {
	@Autowired
	BusRouteService busRouServ;
	
	@GetMapping("/getBusRoutes/{mySource}/{myDest}")
	@ResponseBody
	public ResponseEntity<Set<BusRoute>> busSearch
	(@PathVariable("mySource")String Source,@PathVariable("myDest")String Destination) throws BusRouteNotFoundException
	{
		Set<BusRoute> availBusSet = null;
		System.out.println("Searching for a Buses");
		availBusSet = busRouServ.busSearchService(Source, Destination);
		boolean isEmpty = availBusSet.isEmpty();
		if(isEmpty==true)
		{
			return ResponseEntity.notFound().build();
		}	
		else
		return ResponseEntity.ok(availBusSet);
	}
	@PostMapping(path="/addBusRoute")
	public String addBusRoute(@RequestBody BusRoute busRou)
	{
		String statusMsg= null;
		try {
			statusMsg=busRouServ.addBusRouteService(busRou);
		} 
		catch (BusRouteAlreadyExistsException e) {
			e.printStackTrace();
			return e.getMessage();
		}
		catch(Exception e)
		{
			e.getMessage();
		}
		return statusMsg;
	}
}
