package com.airbus.controller;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.airbus.pojos.AuthorizedTicket;
import com.airbus.pojos.Registration;
import com.airbus.service.RegistrationService;
import com.airbus.service.exception.RegistrationAlreadyExistsException;
import com.airbus.service.exception.RegistrationNotFoundException;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class RegistrationController
{

		@Autowired
		RegistrationService regServ;
		
		@GetMapping(path="/getreg/{myemail}") //Get Request in Postman http://localhost:8080/getDept/1
		@ResponseBody
		public ResponseEntity<Registration> getRegistration(@PathVariable("myemail") String email) throws RegistrationNotFoundException 
		{
			Registration reg1 = null;
			
			reg1 =	regServ.findRegistrationService(email);
			if(reg1==null)
			{ return ResponseEntity.notFound().build();
			
			}
			else {
				return ResponseEntity.ok(reg1);
			}
		}
		
		
		@GetMapping(path="/getregs")
		@ResponseBody
		public Set<Registration> getAllregs()
		{
			System.out.println("Registration Controller....Understanding client and talking to service layer...");
			Set<Registration> reg1Set = regServ.findRegistrationsService();
			return reg1Set;
			
		}
		
		@PostMapping(path="/addreg")
		public String addRegistration(@RequestBody Registration reg1) 
		{
			String stmsg = null;
			try {
				stmsg = regServ.addRegistrationService(reg1);
			} 
			catch (RegistrationAlreadyExistsException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return e.getMessage();
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			  return stmsg;
		}
		
		@PutMapping(path="/modifyreg")
		public String modifyRegistration(@RequestBody Registration reg1) throws RegistrationNotFoundException 
		{
			 String stmsg = null;
				try {
					stmsg = regServ.modifyRegistrationService(reg1);
				} 
				catch (RegistrationNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					return e.getMessage();
				}
				catch(Exception e) {
					e.printStackTrace();
				}
				  return stmsg;
		}
		
		@DeleteMapping(path="/deletereg")
		public String deleteRegistration(@RequestBody Registration reg1) throws RegistrationNotFoundException
		{
			String stmsg = null;
			try {
				stmsg = regServ.removeRegistrationService(reg1.getEmail());
			} 
			catch (RegistrationNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return e.getMessage();
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			  return stmsg;	
		}
		
		@PostMapping(path="/login")
		public Registration authentication(@RequestBody Registration userDetails) throws RegistrationNotFoundException
		{
			Registration authenticatedUser= new Registration();
			authenticatedUser=regServ.userAuthenticationService(userDetails.getEmail(), userDetails.getPassword());
			return authenticatedUser;
		}
}