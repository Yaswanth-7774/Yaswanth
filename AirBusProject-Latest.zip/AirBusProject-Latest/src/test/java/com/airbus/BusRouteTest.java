package com.airbus;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.airbus.pojos.Bus;
import com.airbus.pojos.BusRoute;
import com.airbus.pojos.Reservation;
import com.airbus.repos.BusRepository;
import com.airbus.repos.BusRouteRepository;
import com.airbus.service.BusRouteService;




@SpringBootTest
class BusRouteTest {

	@Autowired
    BusRouteRepository busRouRepo;
	BusRepository busRepo;
	BusRouteService busRouServ;
	/*
	@Test
	void busRouteByRouteNo() {
		
		BusRoute bRou =bRouRepo.findBusRoute(123);
	    System.out.println(bRou.getDestination());
	    System.out.println(bRou.getEndTime());
	    System.out.println(bRou.getFacility());
	    System.out.println(bRou.getSource());
	    System.out.println(bRou.getStartTime());
	    System.out.println(bRou.getResvSet());
	}
	*/
	@Test
    void addBusRoute()
    {
        //Bus busObj= busRepo.findBus(789);
        BusRoute busRou = new BusRoute();
        
        Bus busObj= busRepo.findBus(456);
        System.out.println(busObj);
        busRou.setBus(busObj);
        busRou.setRouteNumber(128);
        busRou.setSource("BANGALORE");
        busRou.setDestination("HYDERABAD");
        busRou.setStartTime("23:00");
        busRou.setEndTime("04:00");
        busRou.setFacility("NON-AC");
        busRou.setDistance(570);
        busRou.setFare(500);
        busRouRepo.addBusRoute(busRou);
        System.out.println("Added successfully");
    }
	@Test
	void allReservationsOfRoute() {
		System.out.println("Displaying all the reservations of route number 123");
		
		BusRoute bRou =busRouRepo.findBusRoute(123);
	    System.out.println("Destination "+bRou.getDestination());
	    System.out.println("Source :"+bRou.getSource());
	    System.out.println("Arrival Time :"+bRou.getEndTime());
	    System.out.println("Facility : "+bRou.getFacility());
	    System.out.println("Departure Time"+bRou.getStartTime());
	    System.out.println("Ticket Number :"+bRou.getResvSet());
	    
	    Set<Reservation> resvSet=bRou.getResvSet();
	    for(Reservation res:resvSet)
	    {
	    	System.out.println("TicketNumber :"+res.getTicketNumber());
	    	System.out.println("BookingDate :"+res.getBookingDate());
	    	System.out.println("JourneyDate :"+res.getJourneyDate());
	    	System.out.println("Transaction Id :"+res.getTransactionId());
	    }

	}
	
	/*@Test
	void busSearch() {
		Set<BusRoute> routeList =busRouServ.busSearch("HYDERABAD","BANGALORE");
		boolean isEmpty = routeList.isEmpty();
		if(isEmpty==false)
		{
			System.out.println("SET HAS SOME ELEMENTS");
			for (BusRoute d: routeList) {
			System.out.println("RouteNumber : "+d.getRouteNumber()); System.out.println("BusNumber   : "+d.getBus().getBusNumber());
			System.out.println("Facility    : "+d.getFacility());    System.out.println("StartTime   : "+d.getStartTime());
			System.out.println("End Time    : "+d.getEndTime());     System.out.println("Fare        : "+d.getFare());
			System.out.println("Distance    : "+d.getDistance());    System.out.println("-----------------");
			}
		}
		else
			System.out.println("no buses in this route");
	}*/
}
