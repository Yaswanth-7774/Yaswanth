package com.airbus;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.airbus.pojos.BusRoute;
import com.airbus.pojos.Reservation;
import com.airbus.repos.BusRouteRepository;
import com.airbus.repos.ReservationRepository;



@SpringBootTest
class ReservationTest {

	@Autowired
    ReservationRepository resvRepo;
	BusRouteRepository busRepo;
	@Test
	void resevationByTicketNo() {
		
		Reservation resv=resvRepo.findReservation(4);
	    System.out.println(resv.getBookingDate());
	    System.out.println(resv.getJourneyDate());
	    System.out.println(resv.getSeatNumber());
	    System.out.println(resv.getTicketStatus());
	    System.out.println(resv.getTransactionId());
	    System.out.println(resv.getRescheduledDate());
	    System.out.println(resv.getRefund());
	    System.out.println(resv.getCancellationDate());
	   // System.out.println(resv.getRoute());
	}

	@Test	void addReservation() {
		Reservation resvObj = new Reservation();
		
		resvObj.setTicketNumber(7);
		resvObj.setBookingDate(LocalDate.of(2021, 05,10));
		resvObj.setJourneyDate(LocalDate.of(1996, 05,22));
		resvObj.setCancellationDate(null);
		resvObj.setRescheduledDate(null);
		resvObj.setRefund(null);
		resvObj.setSeatNumber(14);
		//resvObj.setRoute(routeObj.getRouteNumber());
		resvObj.setTicketStatus("CONFIRM");
		resvObj.setTransactionId(2565);
		resvRepo.addReservation(resvObj);
	}
		@Test
		void deleteReservation()
		{
			resvRepo.removeReservation(7);
		}
		@Test
		void findResrvations()
		{
			
		Set<Reservation> rSet=resvRepo.findReservations();
		for(Reservation rs:rSet) {
			System.out.println("BookingDate: "+rs.getBookingDate());
			System.out.println("BookingDate: "+rs.getTicketStatus());
			System.out.println("BookingDate: "+rs.getSeatNumber());
			System.out.println("BookingDate: "+rs.getRoute());
			System.out.println("BookingDate: "+rs.getTransactionId());
			System.out.println("BookingDate: "+rs.getJourneyDate());
			
		}
			
		}
		@Test
		void modifyReservation()
		{
			Reservation resvObj = new Reservation();
			resvObj.setTicketNumber(1);
			resvObj.setBookingDate(LocalDate.of(2021, 05,11));
			resvObj.setJourneyDate(LocalDate.of(2021, 05,12));
			resvObj.setCancellationDate(null);
			resvObj.setRescheduledDate(null);
			resvObj.setTicketStatus("CONFIRM");
			resvObj.setRefund(null);
			resvObj.setSeatNumber(15);
			resvObj.setTransactionId(4961);
			resvRepo.modifyReservation(resvObj);
		}
	
}
