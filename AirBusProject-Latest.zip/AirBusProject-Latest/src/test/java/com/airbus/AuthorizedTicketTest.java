package com.airbus;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import com.airbus.pojos.AuthorizedTicket;
import com.airbus.pojos.Registration;
import com.airbus.pojos.Reservation;
import com.airbus.repos.AuthorizedTicketRepository;
@SpringBootTest
 class AuthorizedTicketTest {
   @Autowired
   AuthorizedTicketRepository authRepo;
   Registration regRepo;
    @Test
    void findAuthTicket()
    {
    	AuthorizedTicket auth = authRepo.findAuthorizedTicket(1);
    	System.out.println(auth.getId());
    	System.out.println(auth.getReservation());
    	System.out.println(auth.getRegistration());
    	System.out.println("-----------------");
    }
    
    @Test
    void addAuthTicket()
    {

    	AuthorizedTicket authobj1 = new AuthorizedTicket();
    	authobj1.setId(7);
    	
    	authRepo.addAuthorizedTicket(authobj1);
	
    }
    
    @Test
    void deleteAuthTicket()
    {
    	authRepo.removeAuthorizedTicket(1);
    	 }
    @Test
    void test()
    {
    	AuthorizedTicket authobj1 = new AuthorizedTicket();
    	authobj1.setId(8);	
    	authRepo.modifyAuthorizedTicket(authobj1);
    }
@Test
    
    void TicketStatusForAuth() {
    	AuthorizedTicket auth = authRepo.findAuthorizedTicket(1);
    	System.out.println(auth.getId());
    	//System.out.println(auth.getReservation());
    	System.out.println("-----------------");
    	
    	Reservation res = auth.getReservation();
    	
    	System.out.println(res.getTicketStatus());
    	
    }
    
}