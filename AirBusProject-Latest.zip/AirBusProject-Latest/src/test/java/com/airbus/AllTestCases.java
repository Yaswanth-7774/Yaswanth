package com.airbus;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.airbus.pojos.Bus;
import com.airbus.pojos.BusRoute;
import com.airbus.pojos.Reservation;
import com.airbus.repos.BusRepository;
import com.airbus.repos.BusRouteRepository;
import com.airbus.repos.ReservationRepository;
@SpringBootTest
class AllTestCases {
	@Autowired
    BusRouteRepository busRouRepo;
	@Autowired
	BusRepository busRepo;
	@Autowired
	ReservationRepository reservRepo;
	@Test
	void busRouteByRouteNo() {
		
		BusRoute bRou =busRouRepo.findBusRoute(123);
	    System.out.println(bRou.getDestination());
	    System.out.println(bRou.getEndTime());
	    System.out.println(bRou.getFacility());
	    System.out.println(bRou.getSource());
	    System.out.println(bRou.getStartTime());
	    //System.out.println(bRou.getResvSet());
	}

	/*
	 * This method helps user to search for buses by entering source and destination
	 */
	@Test
	void busSearch() {
		Set<BusRoute> routeList =busRouRepo.busSearch("HYDERABAD","BANGALORE");
		boolean isEmpty = routeList.isEmpty();
		if(isEmpty==false)
		{
			System.out.println("SET HAS SOME ELEMENTS");
			for (BusRoute d: routeList) {
			System.out.println("RouteNumber : "+d.getRouteNumber()); System.out.println("BusNumber   : "+d.getBus().getBusNumber());
			System.out.println("Facility    : "+d.getFacility());    System.out.println("StartTime   : "+d.getStartTime());
			System.out.println("End Time    : "+d.getEndTime());     System.out.println("Fare        : "+d.getFare());
			System.out.println("Distance    : "+d.getDistance());    System.out.println("-----------------");
			}
		}
		else
			System.out.println("no buses in this route");
	}
	@Test
	void findAllReservationsByRouteNumber()
	{
		Set<Reservation> reservSet = reservRepo.findReservationsOfaRoute(123);
		boolean isEmpty = reservSet.isEmpty();
		if(isEmpty==false)
		{
			for(Reservation r: reservSet)
			{
				System.out.println("Ticket Number   : "+r.getTicketNumber());  System.out.println("Seat Number     : "+r.getSeatNumber());
				System.out.println("Journey Date    : "+r.getJourneyDate());   System.out.println("Booking Date    : "+r.getBookingDate());
				System.out.println("Transaction id  : "+r.getTransactionId()); System.out.println("Ticket Status   : "+r.getTicketStatus());
				System.out.println("----------------------------------------");
			}
		}
		else
			System.out.println("No reservations in this route");
	}
	
	@Test
	void findReservationByTransId()
	{
		Reservation r = reservRepo.findReservationUsingTransactionId(3356);
		System.out.println("Ticket Number   : "+r.getTicketNumber()); System.out.println("Seat Number     : "+r.getSeatNumber());
		System.out.println("Route Number  : "+r.getRoute().getRouteNumber());System.out.println("Journey Date    : "+r.getJourneyDate()); 
		System.out.println("Booking Date    : "+r.getBookingDate());System.out.println("Ticket Status   : "+r.getTicketStatus());
	}
	
	@Test
	void findAllReservations()
	{
		Set<Reservation> reservSet = reservRepo.findReservations();
		boolean isEmpty = reservSet.isEmpty();
		if(isEmpty==false)
		{
			for(Reservation r: reservSet)
			{
				System.out.println("Ticket Number   : "+r.getTicketNumber()); 
				System.out.println("Seat Number     : "+r.getSeatNumber());
				System.out.println("Journey Date    : "+r.getJourneyDate());    
				System.out.println("Booking Date    : "+r.getBookingDate());
				System.out.println("Transaction id  : "+r.getTransactionId());     
				System.out.println("Ticket Status   : "+r.getTicketStatus());
			}
		}
		else
			System.out.println("No reservations");
	}
	@Test
	void addBusRoute()
	{
		Bus busObj= busRepo.findBus(700);
		BusRoute busRou = new BusRoute();
		busRou.setRouteNumber(122);
		System.out.println(busObj);
		busRou.setBus(busObj);
		busRou.setSource("HYDERABAD");
		busRou.setDestination("VIJAYAWADA");
		busRou.setStartTime("23:00");
		busRou.setEndTime("04:00");
		busRou.setFacility("NON-AC");
		busRou.setDistance(570);
		busRou.setFare(500);
		busRouRepo.addBusRoute(busRou);
		System.out.println("Added successfully");
	}
	/*
	 * @Test void findReservationsOfaRoute() { Set<Reservation> reservSet =
	 * reservRepo.findReservationsOfaRouteByDate(Reservation.setJourneyDate(
	 * LocalDate.of(2021, 05,15))); boolean isEmpty = reservSet.isEmpty();
	 * if(isEmpty==false) { for(Reservation r: reservSet) {
	 * System.out.println("Ticket Number   : "+r.getTicketNumber());
	 * System.out.println("Seat Number     : "+r.getSeatNumber());
	 * System.out.println("Journey Date    : "+r.getJourneyDate());
	 * System.out.println("Booking Date    : "+r.getBookingDate());
	 * System.out.println("Transaction id  : "+r.getTransactionId());
	 * System.out.println("Ticket Status   : "+r.getTicketStatus()); } } else
	 * System.out.println("No reservations"); }
	 */
}
